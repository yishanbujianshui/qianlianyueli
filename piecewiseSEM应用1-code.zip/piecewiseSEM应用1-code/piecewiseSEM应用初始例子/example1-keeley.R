library(tidyverse)
library(lavaan)
library(piecewiseSEM)

keeley<-read.csv("2_keeley.csv")
#----------------------------- fit the model using psem()
keeley.sem<-psem(
	lm(abiotic~distance, data=keeley),
	lm(hetero~distance,data=keeley),
	lm(rich~abiotic+hetero,data=keeley),
	data=keeley
)

keeley.sem

#---------------------------------------evaluate the fit
#get the basis set
basisSet(keeley.sem)

#conduct d-sep test
keeley.dsep<-dSep(keeley.sem)
keeley.dsep
dSep(keeley.sem,conditioning=T)

#compute Fisher's C
fisherC(keeley.sem)

#by yourself
(C<-(-2)*sum(log(keeley.dsep$P.Value)))
1-pchisq(C,2*nrow(keeley.dsep))

#add significant path
keeley.sem2<-update(keeley.sem,rich~distance+abiotic+hetero)#直接用显著的independence claims方程替换原来的rich~
keeley.sem2

#再次评估
basisSet(keeley.sem2)
dSep(keeley.sem2,conditioning=T)
fisherC(keeley.sem2)

#---------------------------------------obtain the coefficients and R2
coefs(keeley.sem2)
coefs(keeley.sem2,intercepts=T)
rsquared(keeley.sem2)

#---------------------------------------get all summary information one time
summary(keeley.sem2)

#---------------------------------------compare to lavaan
lavaan.sem<-sem(
	model="abiotic~distance
	hetero~distance
	rich~distance+abiotic+hetero",
	data=keeley)

summary(lavaan.sem,rsq=T,standardize=T)

# considering the correlated errors
keeley.sem3<-psem(
	lm(abiotic~distance, data=keeley),
	lm(hetero~distance,data=keeley),
	lm(rich~distance+hetero,data=keeley),
	rich%~~%abiotic,
	data=keeley
)
summary(keeley.sem3)

#--------------------------------------compare models using AIC
keeley.sem4<-psem(
	lm(hetero~distance,data=keeley),
	lm(rich~distance+hetero,data=keeley),
	abiotic~1,
	data=keeley
)
summary(keeley.sem4)
AIC(keeley.sem4)
BIC(keeley.sem4)


keeley.sem5<-psem(
	lm(hetero~distance,data=keeley),
	lm(rich~distance+hetero,data=keeley),
	data=keeley
)
summary(keeley.sem5)

keeley.sem6<-psem(
	lm(hetero~distance,data=keeley),
	lm(rich~distance+hetero+abiotic,data=keeley),
	data=keeley
)
summary(keeley.sem6)


#-----------------------------局部路径关系的图形表达
#1.偏回归图 partial regression, also called added-variable plot
resids<-partialResid(rich~distance,keeley.sem2)
ggplot(data=resids,aes(x=xresid,y=yresid))+
	geom_point(size=2)+
	stat_smooth(method=lm,color="red")+
	xlab("distance | others")+
	ylab("rich | others")

#--试下car::avPlot()
keeley.sem2[[3]]#psem对象是一组模型的列表，可以直接取出来
avPlot(keeley.sem2[[3]],variable="distance")

#2.marginal plot，即用原始数据回归两个变量，不管其他。
ggplot(data=keeley,aes(x=distance,y=rich))+
	geom_point()+
	stat_smooth(method=lm,color="red")

#3.predictor effect plot,固定其他预测变量在中值或均值
library(visreg)
visreg(keeley.sem2[[3]],xvar="distance")
vr<-visreg(keeley.sem2[[3]],xvar="distance")
vr
ggplot()+
	geom_point(data=keeley,aes(x=distance,y=rich))+
	geom_line(data=vr$fit,aes(x=distance,y=visregFit),color="red",size=1)+
	geom_ribbon(data=vr$fit,aes(x=distance,ymin=visregLwr,ymax=visregUpr),fill="gray50",alpha=0.4)
#试下effects::predictorEffect()
library(effects)
pr<-predictorEffect(mod=keeley.sem2[[3]],predictor="distance")#其他自变量固定在均值
pr<-as.data.frame(pr)
ggplot()+
	geom_point(data=keeley,aes(x=distance,y=rich))+
	geom_line(data=pr,aes(x=distance,y=fit),color="red",size=1)+
	geom_ribbon(data=pr,aes(x=distance,ymin=lower,ymax=upper),color="gray60",alpha=0.4)

