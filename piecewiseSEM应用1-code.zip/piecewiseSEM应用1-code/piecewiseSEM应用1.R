
##############################结构方程模型2020.11 线上#######################
#----------------------------piecewiseSEM的应用1 code----------------------------------

library(piecewiseSEM)
library(tidyverse)
library(nlme)
library(lme4)
library(brms)
library(ape)
library(caper)
#---安装ggtree
if(!requireNamespace("BiocManager",quietly=TRUE))
	install.packages("BiocManager")
BiocManager::install("ggtree")
library(ggtree)
library(tidytree)


#########################线性混合模型SEM,lefcheck---case1##############################
kelp<-read.csv("kelp.csv")
as_tibble(kelp)

#----------------------------------------------------数据的前期处理
# Convert -Inf to NA
kelp$max_Max.OV[which(kelp$max_Max.OV == -Inf)] = NA

# Log response variables to mirror original analysis of Byrnes et al 2011
kelp$kelp<-log(kelp$kelp+1)
kelp$prev.kelp<-log(kelp$prev.kelp + 1)
kelp[,18:23]<-log(kelp[,18:23] + 1)

# select the target data and remove rows where response or predictors are NA
vars = c("SITE", "TRANSECT", "YEAR", "max_Max.OV", "prev.kelp", "habitat", "spring_canopy_150", "kelp", 
				 "algae_richness", "sessile_invert_richness", "mobile_richness", "richness", "consumer_richness", "linkdensity")
kelp = kelp[, vars]
kelp = na.omit(kelp)

# Create interaction term  😝有意思！
kelp$wave_kelp_int = kelp$max_Max.OV * kelp$prev.kelp
as_tibble(kelp)
ggplot()+geom_histogram(aes(x=kelp$kelp),color="white")

#-----------------------------------------------------基于概念模型建立SEM，开展psem拟合
lefcheck.sem1<-psem(
	
	# Predicting spring kelp canopy
	lme(spring_canopy_150 ~ max_Max.OV * prev.kelp + habitat, random = ~ 1 | SITE, data = kelp),
	
	# Predicting summer kelp density
	lme(kelp ~ max_Max.OV + prev.kelp  + habitat + spring_canopy_150, random = ~ 1 | SITE, data = kelp),
	
	# Predicting total richness
	lme(richness ~ kelp + prev.kelp + habitat + spring_canopy_150, random = ~ 1 | SITE, data = kelp),
	
	# Predict linkage density
	lme(linkdensity ~ richness + kelp + prev.kelp + habitat + spring_canopy_150, random = ~ 1 | SITE, data = kelp),
	
	data=kelp
)

#或者先建立列表，as.psem()转
kelp_pSEM_randomList = list(
	
	# Predicting spring kelp canopy
	lme(spring_canopy_150 ~ max_Max.OV * prev.kelp + habitat, random = ~ 1 | SITE, data = kelp),
	
	# Predicting summer kelp density
	lme(kelp ~ max_Max.OV + prev.kelp  + habitat + spring_canopy_150, random = ~ 1 | SITE, data = kelp),
	
	# Predicting total richness
	lme(richness ~ kelp + prev.kelp + habitat + spring_canopy_150, random = ~ 1 | SITE, data = kelp),
	
	# Predict linkage density
	lme(linkdensity ~ richness + kelp + prev.kelp + habitat + spring_canopy_150, random = ~ 1 | SITE, data = kelp)
	
)

lefcheck.sem1<-as.psem(kelp_pSEM_randomList)

#---------------------------------------------查看结果
summary(lefcheck.sem1)
basisSet(lefcheck.sem1)
dSep(lefcheck.sem1)#conditioning=T,显示所有自变量
fisherC(lefcheck.sem1)#
coefs(lefcheck.sem1)#intercept=T,给出截距
rsquared(lefcheck.sem1)#默认方法是delta,可改为method="theoretical"则是用的日本人的方法计算R2了
AIC(lefcheck.sem1)
plot(lefcheck.sem1,node_attrs = list(shape = "rectangle", color = "black",fillcolor = "grey"))


#------------------------------------------------加入随机效应并说明时间自相关
lefcheck.sem2<-psem(
	
	lme(spring_canopy_150 ~ max_Max.OV * prev.kelp + habitat,
													random = ~ 1 | SITE/TRANSECT, correlation = corCAR1(form = ~ YEAR), data = kelp),

	lme(kelp ~ max_Max.OV * prev.kelp  + habitat + spring_canopy_150,
						 random = ~ 1 | SITE/TRANSECT, correlation = corCAR1(form = ~ YEAR), data = kelp),

	lme(richness ~ kelp + prev.kelp + habitat + spring_canopy_150,
								 random = ~ 1 | SITE/TRANSECT, correlation = corCAR1(form = ~ YEAR), data = kelp),

	lme(linkdensity ~ richness + kelp + prev.kelp + habitat + spring_canopy_150,
										random = ~ 1 | SITE/TRANSECT, correlation = corCAR1(form = ~ YEAR), data = kelp),
	data=kelp
)

summary(lefcheck.sem2)
fisherC(lefcheck.sem2)
coefs(lefcheck.sem2)

#---------------------------------------------将模型中的物种丰富度细分为3种，分析对这些物种丰富度的影响
lefcheck.sem3<-psem(
	
lme(spring_canopy_150 ~ max_Max.OV + prev.kelp + wave_kelp_int + habitat, random = ~ 1 | SITE, data = kelp),
	
lme(kelp ~ max_Max.OV + prev.kelp  + spring_canopy_150 + habitat, random = ~ 1 | SITE, data = kelp),
	
lme(algae_richness ~ max_Max.OV + kelp + prev.kelp + spring_canopy_150 + habitat , random = ~ 1 | SITE, data = kelp),
	
lme(sessile_invert_richness ~ max_Max.OV + kelp + prev.kelp + spring_canopy_150 + habitat , random = ~ 1 | SITE, data = kelp),
	
lme(mobile_richness ~ max_Max.OV + kelp + prev.kelp + spring_canopy_150 + habitat, random = ~ 1 | SITE, data = kelp),

mobile_richness %~~% algae_richness,#模拟相关误差

mobile_richness %~~% sessile_invert_richness,#模拟相关误差

sessile_invert_richness %~~% algae_richness,#模拟相关误差

data=kelp
	
)

summary(lefcheck.sem3)


#########################谱系结构方程模型,lefcheck---case2##############################

#-------读入数据
synalpheus<-read.csv("synalpheus.csv")
# Replace species name，保证和已有树的物种名一致
synalpheus$Species <- as.character(synalpheus$Species)
synalpheus[synalpheus$Species == "longsm", "Species"] <- "longicarpus_small"

#-------读入并查看树
synalpheus.tree<-read.tree("synalpheus_tree.txt")
synalpheus.tree%>%names
synalpheus.tree$tip.label
tidytree::as_tibble(synalpheus.tree)
plot(synalpheus.tree)

ggtree::ggtree(synalpheus.tree,aes(color=label),size=0.3)+
	geom_tiplab()

#-------修剪树 Drop tips not found in the synalpheus dataset
synalpheus.tree<-drop.tip(synalpheus.tree, synalpheus.tree$tip.label[!synalpheus.tree$tip.label %in% unique(synalpheus$Species)])
synalpheus.tree$tip.label

ggtree::ggtree(synalpheus.tree,aes(color=label),size=0.3)+
	geom_tiplab()

#-------使得数据框物种排列和树中的tip顺序一致
rownames(synalpheus) <-synalpheus$Species
synalpheus<-synalpheus[synalpheus.tree$tip.label, ]
synalpheus

#______开展piecewiseSEM 用nlme::gls()
lefcheck.sem4<-psem(
	gls(Host.Range ~ Eusociality.index + Total.Mass.Female, correlation = corBrownian(0.5, synalpheus.tree), na.action = na.omit, data=synalpheus),
	gls(Rubble.Abundance ~ Eusociality.index + Host.Range, correlation = corBrownian(0.5, synalpheus.tree), na.action = na.omit, data=synalpheus),
	data=synalpheus
)

summary(lefcheck.sem4)
fisherC(lefcheck.sem4)
coefs(lefcheck.sem4)
rsquared(lefcheck.sem4)

#______开展piecewiseSEM 用caper::pgls()，有问题啊！
synalpheus.merge <- comparative.data(synalpheus.tree, synalpheus, names.col = "Species")
fortify(synalpheus.merge)
lefcheck.sem5<-psem(
	pgls(Host.Range ~ Eusociality.index + Total.Mass.Female, synalpheus.merge),
  pgls(Rubble.Abundance ~ Eusociality.index + Host.Range, synalpheus.merge)
)
summary(lefcheck.sem5)
fisherC(lefcheck.sem5)
coefs(lefcheck.sem5)


############################### 广义线性模型SEM #######################################

#——————————————————————————————————————poisson分布，模拟数据，手动计算std coef
xm<-data.frame(x1=runif(100),y1=rpois(100,10),y2=rpois(100,50),y3=runif(100))
#建立SE,根据假定的概念模型
poisson.sem<-psem(
	glm(y1~x1,family="poisson",data=xm),
	glm(y2~x1,family="poisson",data=xm),
	lm(y3~y1+y2,data=xm),
	data=xm
)

#--------dSep检验时poisson分布因为有连接函数，所以方向重要，方向不同pi值不同导致fisherC值不同，最终P值不同，影响检验。
summary(poisson.sem)
fisherC(poisson.sem)
dSep(poisson.sem)

coefs(poisson.sem)
rsquared(poisson.sem)

#-------解决方法
summary(poisson.sem,conserve=T)#选择最保守的pi值,查看fisherC,😝推荐！
summary(poisson.sem,direction=c("y2->y1"))#指定方向,查看fisherC
summary(poisson.sem,direction=c("y1->y2"))#指定方向,查看fisherC

#------查看结果
summary(poisson.sem,conserve=T)
summary(poisson.sem,conserve=T)$coefficients
summary(poisson.sem,conserve=T)$R2


#--------------------另一个问题poisson分布不给std coef，自己主持公道！！！！参考Nakagawa 2013 MEE Appendix
#--------计算成分模型1即y1 ~ x1 中x1的标准化路径系数
poisson.sem#查看
poisson.sem[[1]]#取出第一个成分模型，查看

sd.x1<-sd(xm$x1)#x1的标准差

beta0.y1<-update(poisson.sem[[1]],y1~.-x1)%>%coef#null model的截距。exp(as.numeric(beta0.y1))则为期望值，即lambda
possion.var.y1<-log(1+1/exp(as.numeric(beta0.y1)))#泊松分布的方差
predicted.var.y1<-poisson.sem[[1]]%>%predict%>%var#link尺度预测值的方差
sd.y1<-sqrt(predicted.var.y1+possion.var.y1)#y1的标准差

coef.x1<-coef(poisson.sem[[1]])["x1"]

std.coef.x1<-coef.x1*sd.x1/sd.y1
std.coef.x1

#--------计算成分模型2即y2 ~ x1 中x1的标准化路径系数
poisson.sem[[2]]#取出第2个成分模型，查看

sd.x1<-sd(xm$x1)#x1的标准差

beta0.y2<-update(poisson.sem[[2]],y2~.-x1)%>%coef#null model的截距。exp(as.numeric(beta0.y2))则为期望值，即lambda
possion.var.y2<-log(1+1/exp(as.numeric(beta0.y2)))#泊松分布的方差
predicted.var.y2<-poisson.sem[[2]]%>%predict%>%var#link尺度预测值的方差
sd.y2<-sqrt(predicted.var.y2+possion.var.y2)#y2的标准差

coef.x1<-coef(poisson.sem[[2]])["x1"]

std.coef.x1<-coef.x1*sd.x1/sd.y2
std.coef.x1

#——————————————————————————————————————binomial分布，模拟数据，piecewiseSEM能够给出std coef
#计算的原理等同，只是binomial分布, logit连接时，分布的方差用pi^2/3来计算。
yd<-data.frame(x1=runif(100),y1=rbinom(100,1,0.5),y2=rbinom(100,1,0.5),y3=runif(100))
yd

#建立SE,根据假定的概念模型
binomial.sem<-psem(
	glm(y1~x1,family="binomial",data=yd),
	glm(y2~x1,family="binomial",data=yd),
	lm(y3~y1+y2,data=yd),
	data=yd
)

#--------dSep检验时binomial分布因为有连接函数，所以方向重要，方向不同pi值不同导致fisherC值不同，最终P值不同，影响检验。
summary(poisson.sem)
fisherC(poisson.sem)
dSep(poisson.sem)

coefs(poisson.sem)
rsquared(poisson.sem)


#-------解决方法
summary(binomial.sem,conserve=T)#选择最保守的pi值,查看fisherC,😝推荐！
summary(binomial.sem,direction=c("y2->y1"))#指定方向,查看fisherC
summary(binomial.sem,direction=c("y1->y2"))#指定方向,查看fisherC

#--------查看结果
summary(binomial.sem,conserve=T)
summary(binomial.sem,conserve=T)$coefficients
summary(binomial.sem,conserve=T)$R2


############################### 广义线性混合模型SEM #######################################

#------------------------------------------poisson分布
cx<-data.frame(x1=runif(200),y1=rpois(200,10),y2=rpois(200,50),y3=runif(200),species=rep(LETTERS[1:20],each=10))
glmer.poisson.sem<-psem(
	glmer(y1~x1+(1|species),family="poisson",data=cx),
	glmer(y2~x1+(1|species),family="poisson",data=cx),
	lm(y3~y1+y2,data=cx),
	data=cx
)
summary(glmer.poisson.sem,conserve=T)#依然没有标准化路径系数,手动计算

#--------计算成分模型1即y1 ~ x1 中x1的标准化路径系数
glmer.poisson.sem#查看
glmer.poisson.sem[[1]]#取出第一个成分模型，查看

sd.x1<-sd(cx$x1)#x1的标准差

glmer.beta0.y1<-update(glmer.poisson.sem[[1]],y1~.-x1)%>%fixef#null model的截距。exp(as.numeric(glmer.beta0.y1))则为期望值，即lambda
glmer.possion.var.y1<-log(1+1/exp(as.numeric(glmer.beta0.y1)))#泊松分布的方差
glmer.random.var.y1<-VarCorr(glmer.poisson.sem[[1]])%>%as.numeric%>%sum #随机效应的方差
glmer.predicted.var.y1<-glmer.poisson.sem[[1]]%>%predict(re.form=NA)%>%var#link尺度预测值的方差
sd.y1<-sqrt(glmer.predicted.var.y1+glmer.random.var.y1+glmer.possion.var.y1)#y1的标准差

fixef.x1<-fixef(glmer.poisson.sem[[1]])["x1"]

std.coef.x1<-fixef.x1*sd.x1/sd.y1
std.coef.x1

#--------计算成分模型2即y2 ~ x1 中x1的标准化路径系数
glmer.poisson.sem#查看
glmer.poisson.sem[[2]]#取出第一个成分模型，查看

sd.x1<-sd(cx$x1)#x1的标准差

glmer.beta0.y2<-update(glmer.poisson.sem[[2]],y1~.-x1)%>%fixef#null model的截距。exp(as.numeric(glmer.beta0.y1))则为期望值，即lambda
glmer.possion.var.y2<-log(1+1/exp(as.numeric(glmer.beta0.y2)))#泊松分布的方差
glmer.random.var.y2<-VarCorr(glmer.poisson.sem[[2]])%>%as.numeric%>%sum #随机效应的方差
glmer.predicted.var.y2<-glmer.poisson.sem[[2]]%>%predict(re.form=NA)%>%var#link尺度预测值的方差
sd.y2<-sqrt(glmer.predicted.var.y2+glmer.random.var.y2+glmer.possion.var.y2)#y1的标准差

fixef.x1<-fixef(glmer.poisson.sem[[2]])["x1"]

std.coef.x1<-fixef.x1*sd.x1/sd.y2
std.coef.x1


#------------------------------------------binomial分布,模拟数据，piecewiseSEM也给不出std coef
yz<-data.frame(x1=runif(200),y1=rbinom(200,1,0.5),y2=rbinom(200,1,0.5),y3=runif(200),species=rep(LETTERS[1:20],each=10))
glmer.binomial.sem<-psem(
	glmer(y1~x1+(1|species),family="binomial",data=yz),
	glmer(y2~x1+(1|species),family="binomial",data=yz),
	lm(y3~y1+y2,data=yz),
	data=yz
)
summary(glmer.binomial.sem,conserve=T)#二分类广义线性混合模型也没有给出std coef

#--------计算成分模型1即y1 ~ x1 中x1的标准化路径系数
glmer.binomial.sem#查看
glmer.binomial.sem[[1]]#取出第一个成分模型，查看

sd.x1<-sd(yz$x1)#x1的标准差

glmer.binomial.var.y1<-pi^2/3#bionomial分布的方差
glmer.random.var.y1<-VarCorr(glmer.binomial.sem[[1]])%>%as.numeric%>%sum #随机效应的方差
glmer.predicted.var.y1<-glmer.binomial.sem[[1]]%>%predict(re.form=NA)%>%var#link尺度预测值的方差
sd.y1<-sqrt(glmer.predicted.var.y1+glmer.random.var.y1+glmer.binomial.var.y1)#y1的标准差

fixef.x1<-fixef(glmer.binomial.sem[[1]])["x1"]

std.coef.x1<-fixef.x1*sd.x1/sd.y1
std.coef.x1

#--------计算成分模型2即y2 ~ x1 中x1的标准化路径系数
glmer.binomial.sem#查看
glmer.binomial.sem[[2]]#取出第一个成分模型，查看

sd.x1<-sd(yz$x1)#x1的标准差

glmer.binomial.var.y2<-pi^2/3#bionomial分布的方差
glmer.random.var.y2<-VarCorr(glmer.binomial.sem[[2]])%>%as.numeric%>%sum #随机效应的方差
glmer.predicted.var.y2<-glmer.binomial.sem[[2]]%>%predict(re.form=NA)%>%var#link尺度预测值的方差
sd.y2<-sqrt(glmer.predicted.var.y2+glmer.random.var.y2+glmer.binomial.var.y2)#y1的标准差

fixef.x1<-fixef(glmer.binomial.sem[[2]])["x1"]

std.coef.x1<-fixef.x1*sd.x1/sd.y2
std.coef.x1
